var clicknb = 0;
const regex = /(?:poussin|poussins|poule|poules|coq|coqs)/i;
